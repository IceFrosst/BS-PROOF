"""
Deterministic scoring. No model may enter this file.
Implements SPEC.md sections 7-9.
"""
from __future__ import annotations
import math
from dataclasses import dataclass, field

DESIGN_W = {4:1.00, 5:0.55, 6:0.30, 7:0.18, 8:0.12, 9:0.07,
            10:0.03, 11:0.015, 12:0.004, 13:0.0015, 14:0.00}
SYNTHESIS_RANKS = {1, 2, 3}

ROB_FACTOR = {"low":1.00, "some_concerns":0.60, "high":0.25}
FUNDING_FACTOR = {"independent":1.00, "industry_other":0.90,
                  "undisclosed":0.80, "brand_funded":0.60}
FORM_FACTOR = {"exact":1.00, "salt_family":0.50, "different":0.15, "unspecified":0.30}
DOSE_FACTOR = {"in_band":1.00, "low_50_99":0.45, "below_50":0.10, "above_200":0.60}
POP_FACTOR  = {"exact":1.00, "adjacent":0.70, "different":0.35}
OA_FACTOR   = {"full_text":1.00, "sr_table":0.85, "abstract_only":0.55}

S_VALUE = {"benefit_meaningful":1.0, "benefit_trivial":0.3,
           "null_effect":-0.7, "harm":-1.0}

K = 3.0                 # confidence saturation. CALIBRATE ON TIER-3.
LAMBDA = 0.3            # synthesis multiplier ceiling
H_PENALTY = 0.4
GATE_MIN_HUMAN_WD = 0.5

BANDS = [(70,101,"strong support"), (30,70,"moderate support"),
         (10,30,"weak support"), (-9,10,"inconclusive"),
         (-40,-9,"weak evidence against"), (-70,-40,"does not work"),
         (-101,-70,"strong evidence against / harm")]


def rob_band(items: dict) -> tuple[str, int, int]:
    scored = [v for v in items.values() if v in (0, 1)]
    n_known = len(scored); hits = sum(scored)
    if hits >= 5: return "low", hits, n_known
    if hits >= 3: return "some_concerns", hits, n_known
    return "high", hits, n_known


def size_factor(n: int | None) -> float:
    if not n or n <= 1: return 0.2
    return min(1.0, math.log10(n) / 2.0)


@dataclass
class Study:
    id: str
    design_rank: int
    n: int | None = None
    rob_items: dict = field(default_factory=dict)
    funding: str = "undisclosed"
    venue_ok: bool = True
    retracted: bool = False
    oa: str = "abstract_only"
    rob_inherited: bool = False
    form_match: str = "unspecified"
    dose_match: str = "in_band"
    pop_match: str = "exact"
    direction: str = "null_effect"
    magnitude: str | None = None

    def s_value(self) -> float:
        if self.direction == "harm": return S_VALUE["harm"]
        if self.direction == "null_effect": return S_VALUE["null_effect"]
        if self.direction == "benefit":
            return S_VALUE["benefit_trivial"] if self.magnitude == "trivial" \
                   else S_VALUE["benefit_meaningful"]
        return 0.0

    def weight(self) -> float:
        if self.retracted or not self.venue_ok: return 0.0
        wd = DESIGN_W.get(self.design_rank, 0.0)
        if wd == 0.0: return 0.0
        band, _, _ = rob_band(self.rob_items)
        w = wd * ROB_FACTOR[band] * size_factor(self.n)
        w *= FUNDING_FACTOR.get(self.funding, 0.8)
        w *= OA_FACTOR.get(self.oa, 0.55)
        if self.rob_inherited: w *= 0.85
        w *= FORM_FACTOR.get(self.form_match, 0.30)
        w *= DOSE_FACTOR.get(self.dose_match, 0.45)
        w *= POP_FACTOR.get(self.pop_match, 0.35)
        return w


def score_ecu(primaries: list[Study], syntheses: list[dict] | None = None,
              n_unique: int | None = None):
    """
    primaries: UNIQUE primary studies only. Dedup happens before this is called.
    syntheses: [{"included_ids": set, "q_s": float, "resolved": bool}, ...]
    """
    syntheses = syntheses or []
    human = [s for s in primaries if s.design_rank <= 11]
    gate_mass = sum(DESIGN_W.get(s.design_rank, 0) for s in human)
    if gate_mass < GATE_MIN_HUMAN_WD:
        return {"score": None, "band": "insufficient human evidence",
                "gate_fired": True, "n_primaries": len(primaries),
                "n_syntheses": len(syntheses), "gate_mass": round(gate_mass, 3)}

    weights = [s.weight() for s in primaries]
    E = sum(weights)
    if E <= 0:
        return {"score": None, "band": "insufficient human evidence",
                "gate_fired": True, "n_primaries": len(primaries),
                "n_syntheses": len(syntheses), "gate_mass": round(gate_mass, 3)}

    P = {s.id for s in primaries}
    cov, q = 0.0, 0.0
    for syn in syntheses:
        if not syn.get("resolved"): continue
        c = len(set(syn.get("included_ids", ())) & P) / max(len(P), 1)
        if c > cov: cov, q = c, syn.get("q_s", 0.0)
    E_prime = E * (1 + LAMBDA * cov * q)

    d = sum(w * s.s_value() for w, s in zip(weights, primaries)) / E
    c_conf = 1 - math.exp(-E_prime / K)
    mean_s = d
    H = sum(w * (s.s_value() - mean_s) ** 2 for w, s in zip(weights, primaries)) / E
    H = min(1.0, H / 1.5)

    raw = 100 * d * c_conf * (1 - H_PENALTY * H)
    score = max(-100, min(100, round(raw)))
    band = next(b for lo, hi, b in BANDS if lo <= score < hi)

    return {"score": score, "band": band, "gate_fired": False,
            "d": round(d, 3), "c": round(c_conf, 3), "H": round(H, 3),
            "E": round(E, 3), "E_prime": round(E_prime, 3),
            "coverage": round(cov, 3),
            "n_primaries": len(primaries), "n_syntheses": len(syntheses),
            "dedup_ratio": round(len(syntheses) / max(len(primaries), 1), 2)}
